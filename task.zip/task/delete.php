<?php
require_once("config.php");

$id = $_GET['id'];
$sql ="DELETE FROM task_manager WHERE tid='$id'";
$data = mysqli_query($con,$sql);

if ($data) {
  header('location:index.php');
	
}else
{
	echo "error";
}
?>


