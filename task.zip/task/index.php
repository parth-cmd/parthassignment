<?php 
require_once("config.php");



// add task
if(isset($_POST["t-submit"]))
{
    
  $tname=$_POST["task"];
  $asigntask=$_POST['asigntask'];
  $date=$_POST["date"];
  

  $insert="insert into  task_manager (taskname, usid, adddate)values('$tname','$asigntask', '$date')";
  $exe=mysqli_query($con,$insert);
  echo "<div class='alert alert-success col-md-8 mx-auto p-3 mt-4'id='success-alert'>
  <button type='button' class='close' data-dismiss='alert'>x</button>
  <h4 align='center'>Your data successfully Added</h4>
  </div>";
   
    header("refresh:1,index.php");

}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Task Manager APP</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  

</head>

<body>


    <!-- ======= Pricing Section ======= -->
    <section id="pricing" class="pricing">

      <div class="container" data-aos="fade-up">
      
        <div class="section-title">
          
          <h2>Task manager app</h2>
          
        </div>


        <div class="row">

          <div class="col-lg-3" data-aos="fade-up" data-aos-delay="100">            
          </div>

          <div class="col-lg-5 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="200">
            <div class="box featured">
              <center><h2>Task Manager APP</h2></center></br>
              <?php $select="SELECT COUNT(*) FROM task_manager;"; 
                          $exe=mysqli_query($con,$select);
                         $fetch=mysqli_fetch_assoc($exe)
                           ?>
                    <h5>Number Of Task : <?php echo $fetch['COUNT(*)']; ?></h5>
              
                    <?php $selecttask="SELECT task_manager.*, user_name FROM task_manager join user ON task_manager.usid=user.usid;"; 
                          $exe=mysqli_query($con,$selecttask);
                          while($fetch=mysqli_fetch_assoc($exe))
                          {                                        
                    ?>
                      <hr>
                      
                      <h6>Task Name : <?php echo $fetch['taskname'] ?> &nbsp; <?php echo "<a href='delete.php?id=$fetch[tid]'><i class='bi bi-x-circle-fill'></i></a>" ?>  </h6>
                                                                                
                      <h6>Task User : <?php echo $fetch['user_name'] ?> &nbsp;  </h6>
                      
                      <h6>Date Of Completion : <?php echo $fetch['adddate'] ?></h6> 
                     <?php } ?>
              <button  type="submit" name="updatetask" class="buy-btn" data-bs-toggle="modal" data-bs-target="#exampleModal">Add Task</button>
             
            </div>
          </div>

          <div class="col-lg-3 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="300">
            
          </div>

        </div>

      </div>
    </section><!-- End Pricing Section -->

    <!-- Add task model-->
      <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-scrollable" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Assign Task</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
              <form method="post" enctype="multipart/form-data">
                  <div class="mb-3">
                    <label for="task" class="col-form-label">Task Name</label>
                    <input type="text" name="task" class="form-control" id="task" placeholder="Enter task name">
                  </div>
                  <div class="mb-3">

                  <div class="select-wrap">
                  <span class="icon icon-arrow_drop_down"></span>
                  <select name="asigntask" class="form-control d-block rounded-0">
                    <option value="">-select user-</option>
                    <?php $select="select * from user"; 
                          $exe=mysqli_query($con,$select);
                          while($fetch=mysqli_fetch_assoc($exe))
                          {                                        
                    ?>
                    <option value="<?php echo $fetch['usid']; ?>"><?php echo $fetch['user_name'] ?></option>
                    <?php } ?>
                    
                  </select>
                </div>
                 
                  </div>                  

                  <div class="mb-3">                  
                    <label class="col-form-label">Date & Time</label>
                    <input type="date" name="date" class="form-control" id="date">
                  </div> 
                  
                  <div class="mb-3">
                    <hr>
                    <?php $select="SELECT COUNT(*) FROM task_manager;"; 
                          $exe=mysqli_query($con,$select);
                         $fetch=mysqli_fetch_assoc($exe)
                           ?>
                    <h3>Number Of Task : <?php echo $fetch['COUNT(*)']; ?></h3>
                  </div>
                  
                  <div class="row">
                    <div class="col-md-7">
                    <?php $selecttask="SELECT task_manager.*, user_name FROM task_manager join user ON task_manager.usid=user.usid;"; 
                          $exe=mysqli_query($con,$selecttask);
                          while($fetch=mysqli_fetch_assoc($exe))
                          {                                        
                    ?>
                      <hr>
                      
                      <h6>Task Name : <?php echo $fetch['taskname'] ?>  <?php echo "<a href='delete.php?id=$fetch[tid]'><i class='bi bi-x-circle-fill'></i></a>" ?> </h6>
                      <h6>Task User : <?php echo $fetch['user_name'] ?> </h6>
                      <h6>Date Of Completion : <?php echo $fetch['adddate'] ?></h6> 
                     <?php } ?> 
                    </div>
                    <div class="col-md-4 ml-auto">
                    
                    </div>
                  </div>
              </div>              
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" name="t-submit" class="btn btn-primary">Save Task</button>
              </div>
              </form>
            </div>

          </div>
      </div>
<!-- Add task model-->

  </main><!-- End #main -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="assets/js/main.js">
    

$(document).ready(function() {
  $("#success-alert").hide();
  $("#myWish").click(function showAlert() {
    $("#success-alert").fadeTo(2000, 100).slideUp(100, function() {
      $("#success-alert").slideUp(100);
    });
  });
});
  </script>

</body>

</html>