<?php 
require_once("config.php");


if(isset($_POST['updatetask']))
{
  $id=$_POST['id'];
  $tname=$_POST["task"];
  $asigntask=$_POST['asigntask'];
  $date=$_POST["date"];

    
  $update="UPDATE `task_manager` SET taskname='$tname',adddate='$date' WHERE tid='$id'";
  $exe=mysqli_query($con,$update);
  echo "<div class='alert alert-success col-md-8 mx-auto p-3 mt-4'>
  <h4 align='center'>Your data successfully Added</h4>
  </div>";
  // header("refresh:1,index.php");

}

//getting id from url
$id = $_GET['id'];
 
//selecting data associated with this particular id
$result = mysqli_query($con, "SELECT task_manager.*, user_name FROM task_manager join user ON task_manager.usid=user.usid WHERE tid=$id;");
 
while($res = mysqli_fetch_array($result))
{
    $taskname = $res['taskname'];
    $usid = $res['usid'];
    $adddate = $res['adddate'];
}

?>
<!-- Add task model-->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-scrollable" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Task</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
              <form method="POST" enctype="multipart/form-data" action="edit.php">
                  <div class="mb-3">
                    <label for="task" class="col-form-label">Task Name</label>
                    <input type="text" name="task" class="form-control" id="task" value=<?php echo $taskname; ?>>
                  </div>
                  <div class="mb-3">

                  <div class="select-wrap">
                  <span class="icon icon-arrow_drop_down"></span>
                  <select name="asigntask" class="form-control d-block rounded-0">
                    <option value="">-select user-</option>
                    <?php $select="select * from user"; 
                          $exe=mysqli_query($con,$select);
                          while($fetch=mysqli_fetch_assoc($exe))
                          {                                        
                    ?>
                    <option value="<?php echo $fetch['usid']; ?>"><?php echo $fetch['user_name'] ?></option>
                    <?php } ?>
                    
                  </select>
                </div>
                 
                  </div>                  

                  <div class="mb-3">                  
                    <label class="col-form-label">Date & Time</label>
                    <input type="date" name="date" class="form-control" value=<?php echo $adddate; ?> id="date">
                  </div> 
                  
                  <div class="mb-3">
                    <hr>
                    <?php $select="SELECT COUNT(*) FROM task_manager;"; 
                          $exe=mysqli_query($con,$select);
                         $fetch=mysqli_fetch_assoc($exe)
                           ?>
                    <h3>Number Of Task : <?php echo $fetch['COUNT(*)']; ?></h3>
                  </div>
                  
                  <div class="row">
                    <div class="col-md-7">
                    <?php $selecttask="SELECT task_manager.*, user_name FROM task_manager join user ON task_manager.usid=user.usid;"; 
                          $exe=mysqli_query($con,$selecttask);
                          while($fetch=mysqli_fetch_assoc($exe))
                          {                                        
                    ?>
                      <hr>
                      
                      <h6>Task Name : <?php echo $fetch['taskname'] ?>  <a href="delete.php?=<?php echo $fetch['tid'] ?>"><i class="bi bi-x-circle-fill"></i></a> </h6>
                      <h6>Task User : <?php echo $fetch['user_name'] ?> </h6>
                      <h6>Date Of Completion : <?php echo $fetch['adddate'] ?></h6> 
                     <?php } ?> 
                    </div>
                    <div class="col-md-4 ml-auto">
                    
                    </div>
                  </div>
              </div>              
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" name="t-submit" class="btn btn-primary">Update Task</button>
              </div>
              </form>
            </div>

          </div>
      </div>
<!-- Add task model-->